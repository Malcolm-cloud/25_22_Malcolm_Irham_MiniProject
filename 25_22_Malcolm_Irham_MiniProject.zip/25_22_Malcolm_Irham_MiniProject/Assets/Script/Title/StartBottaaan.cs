﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class StartBottaaan : MonoBehaviour
{
   public void StartBotun()
    {
        SceneManager.LoadScene("Level 1");
    }
}
